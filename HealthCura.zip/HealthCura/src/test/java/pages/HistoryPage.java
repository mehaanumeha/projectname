package pages;

public class HistoryPage {

}
